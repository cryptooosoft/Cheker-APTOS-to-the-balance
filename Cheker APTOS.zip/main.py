import asyncio
import json
import multiprocessing
import random
import aiohttp
from python_socks._errors import ProxyError
from utils import PublicKeyUtils
from aptos_sdk.account import Account
from aiohttp_socks import ChainProxyConnector


async def main(_lines):
    f = open('proxies.txt', 'rt')
    socks = random.choice([f"socks5://{p}" for p in f.read().split("\n") if p])
    f.close()
    if not socks:
        print('proxy list empty')
        return
    connector = ChainProxyConnector.from_urls([socks])
    async with aiohttp.ClientSession(connector=connector) as session:
        count = 0
        count_valid = 0
        for line in _lines:
            try:
                pt_account = PublicKeyUtils(line)
                account = Account.load_key(pt_account.private_key.hex())
                r = await session.post("https://indexer.mainnet.aptoslabs.com/v1/graphql", data=json.dumps({
                    "query": "query MyQuery($owner_address: String) {\n current_coin_balances(where: {owner_address: {_eq: $owner_address}}) {\n coin_info {\n coin_type\n coin_type_hash\n decimals\n name\n symbol\n }\n amount\n coin_type\n coin_type_hash\n }\n }",
                    "variables": {
                        "owner_address": str(account.address())}
                }))
                coin_list_raw = (await r.json())['data']['current_coin_balances']
                coin_list = []
                if coin_list_raw:
                    for coin in coin_list_raw:
                        decimals = coin['coin_info']['decimals']
                        amount_raw = coin['amount']
                        symbol = coin['coin_info']['symbol']
                        amount = amount_raw / 10 ** decimals
                        coin_list.append(f"{symbol} - {amount:.4f}")
                r = await session.post("https://indexer.mainnet.aptoslabs.com/v1/graphql", data=json.dumps({
                                                               "query": "query userNftBalanceCount($wallet_address: String) {\n current_token_ownerships_aggregate(\n where: {owner_address: {_eq: $wallet_address}, amount: {_gt: \"0\"}}\n ) {\n aggregate {\n count\n }\n }\n }\n ",
                                                               "variables": {
                                                                   "wallet_address": str(account.address())}
                }))
                amount_nfts = 0
                try:
                    amount_nfts = (await r.json())['data']['current_token_ownerships_aggregate']['aggregate']['count']
                except Exception as ex:
                    print(ex)
                coin_list_str = "\n".join(coin_list)
                if coin_list or amount_nfts > 0:
                    count_valid += 1
                    with open("result.txt", 'a+', encoding='utf-8') as f:
                        f.write(f"""
Address: {str(account.address())}      
Mnemo: {line}
Tokens:
{coin_list_str}
NFT count: {amount_nfts}             
""")
            except ProxyError as e:
                print(f'Ошибка в прокси', e)
            except Exception as e:
                print(e)
            finally:
                count += 1
                print(f"{count}/{len(_lines)}; VALID: {count_valid}")


#asyncio.run(main(["venture venture split lab clip design champion submit quick museum finger search"]))
def starter_main(_lines):
    loop = asyncio.get_event_loop()
    loop.run_until_complete(main(_lines))


if __name__ == "__main__":
    with open("wallets.txt", encoding='utf-8') as f:
        lines = [l for l in f.read().split('\n') if l]
    threads = 10
    step = len(lines) // threads if len(lines) // threads >= 1 else 1
    for i in range(0, len(lines) + step, step):
        multiprocessing.Process(target=starter_main, args=(lines[i:i + step],)).start()
